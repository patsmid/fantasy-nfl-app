const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const cors = require("cors");
const fetch = require("node-fetch");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;

// Ruta persistente para la base de datos (Render Disk montado en /var/data)
const dbPath = "/var/data/database.sqlite";
if (!fs.existsSync("/var/data")) fs.mkdirSync("/var/data", { recursive: true });
const db = new sqlite3.Database(dbPath);

app.use(cors());
app.use(express.static("public"));
app.use(express.json());

// Crear tabla si no existe
db.serialize(() => {
  db.run(\`
    CREATE TABLE IF NOT EXISTS players (
      player_id TEXT PRIMARY KEY,
      full_name TEXT,
      position TEXT,
      team TEXT,
      status TEXT,
      injury_status TEXT,
      years_exp INTEGER
    )
  \`);
});

// Obtener jugadores
app.get("/api/players", (req, res) => {
  db.all("SELECT * FROM players", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Actualizar jugadores desde la API de Sleeper
app.post("/api/update-players", async (req, res) => {
  try {
    const response = await fetch("https://api.sleeper.app/v1/players/nfl");
    const data = await response.json();

    const players = Object.values(data)
      .filter(p => p.active && p.position && p.full_name)
      .map(p => ({
        player_id: p.player_id,
        full_name: p.full_name,
        position: p.position,
        team: p.team || "",
        status: p.status || "",
        injury_status: p.injury_status || "",
        years_exp: p.years_exp || 0
      }));

    const stmt = db.prepare(\`
      INSERT INTO players (player_id, full_name, position, team, status, injury_status, years_exp)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(player_id) DO UPDATE SET
        full_name=excluded.full_name,
        position=excluded.position,
        team=excluded.team,
        status=excluded.status,
        injury_status=excluded.injury_status,
        years_exp=excluded.years_exp
    \`);

    db.serialize(() => {
      players.forEach(p => {
        stmt.run([p.player_id, p.full_name, p.position, p.team, p.status, p.injury_status, p.years_exp]);
      });
    });

    stmt.finalize();
    res.json({ success: true, updated: players.length });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log("Server running on port", PORT);
});